# def polish_notation_w
