def subtraction(a, b):
    return a - b