#!/usr/bin/python

def add(a, b):
    return a + b

# The method below has problems.
# def main():
#     a = 10
#     b = 20
#     print('The sum of {} and {} is {}'.format(a, b, add(a, b))
