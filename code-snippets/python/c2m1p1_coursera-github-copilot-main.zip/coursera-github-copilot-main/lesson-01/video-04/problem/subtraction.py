#!/usr/bin/python

def subtract(a, b):
    return a - b

# The method below has problems.
# def main():
#     a = 10
#     b = 5
#     print 'The result of subtracting { from {} is {}'.format(b, a, subtract(a, b)))
