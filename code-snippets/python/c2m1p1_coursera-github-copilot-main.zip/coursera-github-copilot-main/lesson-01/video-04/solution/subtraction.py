#!/usr/bin/python

def subtract(a, b):
    return a - b


def main():
    a = 10
    b = 5
    print(f'The result of subtracting {b} from {a} is {subtract(a, b)}')


if __name__ == '__main__':
    main()
