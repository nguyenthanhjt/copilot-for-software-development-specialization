# Coursera GitHub Copilot Course

This repository contains the code and resources for the Coursera course "GitHub Copilot".
