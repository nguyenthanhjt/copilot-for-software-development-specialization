# Single, Specific, Short, and Surround

# Python method using list to filter and return even numbers

# Python method using a lambda function to filter and return even numbers

# Python method with a for loop to filter and return even numbers

# Python method to filter even numbers from a list, handle non-intenger values, and raise errors

# Assert statements
